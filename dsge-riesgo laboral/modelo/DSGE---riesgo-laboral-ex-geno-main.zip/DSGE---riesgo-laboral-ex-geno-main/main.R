rm(list = ls())


source("model/parametros.R")
source("model/grids.R")
source("model/Transiciones.R")
source("model/solve.R")
source("model/simulación.R")
